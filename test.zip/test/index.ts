import * as issue from 'issue'; 

issue.foo();